rootProject.name = "ktor-sample"
